# cs2450
CS2450 Software Engineering Group Project

To run this program load it up in visual studio code and run main.py it should then:

prompt for the name of the text file to be read into UVSim and then execute the instructions that were read in.

To run Pytest in the terminal run the command:
Python3 -m pytest
